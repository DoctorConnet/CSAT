﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace CSAT_D5_DOCTORCONNECT
{
    public partial class login1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string cnstring = "Data Source=LAPTOP-HGFB75RB\\SQLEXPRESS;Initial Catalog=APL_CSAT;Integrated Security=True";

        

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(" Data Source=laptop-hgfb75rb\\sqlexpress;Initial Catalog=APL_CSAT;Integrated Security=True");
            con.Open();
            String Checkuser = "Select count(*) from NewUser where Email_address='" + TextBox1.Text + "'";
            SqlCommand com = new SqlCommand(Checkuser, con);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (temp == 1)
            {
                con.Open();
                string checkPasswordQuery = "select password from NewUser where Email_address='" + TextBox1.Text + "'";
                SqlCommand pcom = new SqlCommand(checkPasswordQuery, con);
                string password = pcom.ExecuteScalar().ToString();
                if (password == TextBox2.Text)
                {
                    Response.Redirect("profile.aspx");

                }
                else
                {
                    //Response.Write("Bad username or password");
                    Response.Write("<script>alert('Bad username or password');</script>");
                }
            }
            else
            {

                //Response.Write(" Bad username or password");
                Response.Write("<script>alert('Bad username or password');</script>");
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("signup.aspx");
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}
            
