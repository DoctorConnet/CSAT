﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace CSAT_D5_DOCTORCONNECT
{
    public partial class signup : System.Web.UI.Page
    {
        public string mycnstring = "Data Source=laptop-hgfb75rb\\sqlexpress;Initial Catalog=APL_CSAT;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            {
                SqlConnection con = new SqlConnection(mycnstring);
                con.Open();

                if (con.State == System.Data.ConnectionState.Open)
                {
                    string a = "insert into dbo.NewUser(First_Name,Last_Name,Email_address,password,Month,Date,Year,Gender,Expertise)values('" + TextBox1.Text.ToString() + "' ,'" + TextBox2.Text.ToString() + "', '" + TextBox3.Text.ToString() + "','" + TextBox4.Text.ToString() + "','" + DropDownList1.Text.ToString() + "','" + DropDownList2.Text.ToString() + "','" + DropDownList3.Text.ToString() + "','" + RadioButtonList1.Text.ToString() + "','" + DropDownList4.Text.ToString() + "')";

                    SqlCommand cmd = new SqlCommand(a, con);
                    cmd.ExecuteNonQuery();

                 
                    Response.Write("Register Successfully");

                }
            }
        }
    }
}